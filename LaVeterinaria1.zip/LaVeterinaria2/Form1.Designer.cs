﻿namespace LaVeterinaria1
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.PVertical = new System.Windows.Forms.Panel();
            this.PSubmenu = new System.Windows.Forms.Panel();
            this.BtnMedicamento = new System.Windows.Forms.Button();
            this.BtnEnfermedad = new System.Windows.Forms.Button();
            this.SubReportes = new System.Windows.Forms.Panel();
            this.BtnEnMedicamentos = new System.Windows.Forms.Button();
            this.BtnEnTratadas = new System.Windows.Forms.Button();
            this.BtnComparar = new System.Windows.Forms.Button();
            this.BtnReportes = new System.Windows.Forms.Button();
            this.BtnTratarMascota = new System.Windows.Forms.Button();
            this.BtnMascota = new System.Windows.Forms.Button();
            this.BtnCliente = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.PContenedor = new System.Windows.Forms.Panel();
            this.BtnCierre = new System.Windows.Forms.PictureBox();
            this.BtnMaxi = new System.Windows.Forms.PictureBox();
            this.BtnResta = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.BtnMini = new System.Windows.Forms.PictureBox();
            this.BTitulo = new System.Windows.Forms.Panel();
            this.BtnOpciones = new System.Windows.Forms.Button();
            this.Subcrud = new System.Windows.Forms.Panel();
            this.BtnEdmascota = new System.Windows.Forms.Button();
            this.BtnEdicliente = new System.Windows.Forms.Button();
            this.BtnEdenfermedad = new System.Windows.Forms.Button();
            this.BtnEmedicamentos = new System.Windows.Forms.Button();
            this.PVertical.SuspendLayout();
            this.PSubmenu.SuspendLayout();
            this.SubReportes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnCierre)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnMaxi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnResta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnMini)).BeginInit();
            this.BTitulo.SuspendLayout();
            this.Subcrud.SuspendLayout();
            this.SuspendLayout();
            // 
            // PVertical
            // 
            this.PVertical.BackColor = System.Drawing.Color.Aqua;
            this.PVertical.Controls.Add(this.PSubmenu);
            this.PVertical.Controls.Add(this.SubReportes);
            this.PVertical.Controls.Add(this.BtnOpciones);
            this.PVertical.Controls.Add(this.Subcrud);
            this.PVertical.Controls.Add(this.BtnComparar);
            this.PVertical.Controls.Add(this.BtnReportes);
            this.PVertical.Controls.Add(this.BtnTratarMascota);
            this.PVertical.Controls.Add(this.BtnMascota);
            this.PVertical.Controls.Add(this.BtnCliente);
            this.PVertical.Controls.Add(this.pictureBox1);
            this.PVertical.Dock = System.Windows.Forms.DockStyle.Left;
            this.PVertical.Location = new System.Drawing.Point(0, 42);
            this.PVertical.Name = "PVertical";
            this.PVertical.Size = new System.Drawing.Size(217, 640);
            this.PVertical.TabIndex = 4;
            // 
            // PSubmenu
            // 
            this.PSubmenu.Controls.Add(this.BtnMedicamento);
            this.PSubmenu.Controls.Add(this.BtnEnfermedad);
            this.PSubmenu.Location = new System.Drawing.Point(8, 306);
            this.PSubmenu.Name = "PSubmenu";
            this.PSubmenu.Size = new System.Drawing.Size(241, 81);
            this.PSubmenu.TabIndex = 4;
            this.PSubmenu.Visible = false;
            // 
            // BtnMedicamento
            // 
            this.BtnMedicamento.BackColor = System.Drawing.Color.Aqua;
            this.BtnMedicamento.FlatAppearance.BorderColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.BtnMedicamento.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.BtnMedicamento.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnMedicamento.Font = new System.Drawing.Font("Microsoft YaHei Light", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnMedicamento.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnMedicamento.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnMedicamento.Location = new System.Drawing.Point(3, 43);
            this.BtnMedicamento.Name = "BtnMedicamento";
            this.BtnMedicamento.Size = new System.Drawing.Size(195, 34);
            this.BtnMedicamento.TabIndex = 5;
            this.BtnMedicamento.Text = "Medicamento";
            this.BtnMedicamento.UseVisualStyleBackColor = false;
            this.BtnMedicamento.Click += new System.EventHandler(this.BtnMedicamento_Click);
            // 
            // BtnEnfermedad
            // 
            this.BtnEnfermedad.BackColor = System.Drawing.Color.Aqua;
            this.BtnEnfermedad.FlatAppearance.BorderColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.BtnEnfermedad.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.BtnEnfermedad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnEnfermedad.Font = new System.Drawing.Font("Microsoft YaHei Light", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnEnfermedad.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnEnfermedad.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnEnfermedad.Location = new System.Drawing.Point(3, 3);
            this.BtnEnfermedad.Name = "BtnEnfermedad";
            this.BtnEnfermedad.Size = new System.Drawing.Size(195, 34);
            this.BtnEnfermedad.TabIndex = 4;
            this.BtnEnfermedad.Text = "Enfermedad";
            this.BtnEnfermedad.UseVisualStyleBackColor = false;
            this.BtnEnfermedad.Click += new System.EventHandler(this.BtnEnfermedad_Click);
            // 
            // SubReportes
            // 
            this.SubReportes.Controls.Add(this.BtnEnMedicamentos);
            this.SubReportes.Controls.Add(this.BtnEnTratadas);
            this.SubReportes.Location = new System.Drawing.Point(0, 346);
            this.SubReportes.Name = "SubReportes";
            this.SubReportes.Size = new System.Drawing.Size(241, 81);
            this.SubReportes.TabIndex = 5;
            this.SubReportes.Visible = false;
            // 
            // BtnEnMedicamentos
            // 
            this.BtnEnMedicamentos.BackColor = System.Drawing.Color.Aqua;
            this.BtnEnMedicamentos.FlatAppearance.BorderColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.BtnEnMedicamentos.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.BtnEnMedicamentos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnEnMedicamentos.Font = new System.Drawing.Font("Microsoft YaHei Light", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnEnMedicamentos.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnEnMedicamentos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnEnMedicamentos.Location = new System.Drawing.Point(3, 43);
            this.BtnEnMedicamentos.Name = "BtnEnMedicamentos";
            this.BtnEnMedicamentos.Size = new System.Drawing.Size(206, 34);
            this.BtnEnMedicamentos.TabIndex = 5;
            this.BtnEnMedicamentos.Text = "Entrega Medicamentos";
            this.BtnEnMedicamentos.UseVisualStyleBackColor = false;
            this.BtnEnMedicamentos.Click += new System.EventHandler(this.button1_Click);
            // 
            // BtnEnTratadas
            // 
            this.BtnEnTratadas.BackColor = System.Drawing.Color.Aqua;
            this.BtnEnTratadas.FlatAppearance.BorderColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.BtnEnTratadas.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.BtnEnTratadas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnEnTratadas.Font = new System.Drawing.Font("Microsoft YaHei Light", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnEnTratadas.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnEnTratadas.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnEnTratadas.Location = new System.Drawing.Point(3, 3);
            this.BtnEnTratadas.Name = "BtnEnTratadas";
            this.BtnEnTratadas.Size = new System.Drawing.Size(206, 34);
            this.BtnEnTratadas.TabIndex = 4;
            this.BtnEnTratadas.Text = "Enfermedad Tratadas";
            this.BtnEnTratadas.UseVisualStyleBackColor = false;
            this.BtnEnTratadas.Click += new System.EventHandler(this.button2_Click);
            // 
            // BtnComparar
            // 
            this.BtnComparar.BackColor = System.Drawing.Color.Aqua;
            this.BtnComparar.FlatAppearance.BorderColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.BtnComparar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.BtnComparar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnComparar.Font = new System.Drawing.Font("Microsoft YaHei Light", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnComparar.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnComparar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnComparar.Location = new System.Drawing.Point(28, 346);
            this.BtnComparar.Name = "BtnComparar";
            this.BtnComparar.Size = new System.Drawing.Size(163, 34);
            this.BtnComparar.TabIndex = 5;
            this.BtnComparar.Text = "Comparar";
            this.BtnComparar.UseVisualStyleBackColor = false;
            this.BtnComparar.Click += new System.EventHandler(this.BtnComparar_Click);
            // 
            // BtnReportes
            // 
            this.BtnReportes.BackColor = System.Drawing.Color.Aqua;
            this.BtnReportes.FlatAppearance.BorderColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.BtnReportes.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.BtnReportes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnReportes.Font = new System.Drawing.Font("Microsoft YaHei Light", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnReportes.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnReportes.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnReportes.Location = new System.Drawing.Point(28, 306);
            this.BtnReportes.Name = "BtnReportes";
            this.BtnReportes.Size = new System.Drawing.Size(163, 34);
            this.BtnReportes.TabIndex = 4;
            this.BtnReportes.Text = "Reportes";
            this.BtnReportes.UseVisualStyleBackColor = false;
            this.BtnReportes.Click += new System.EventHandler(this.BtnReportes_Click);
            // 
            // BtnTratarMascota
            // 
            this.BtnTratarMascota.BackColor = System.Drawing.Color.Aqua;
            this.BtnTratarMascota.FlatAppearance.BorderColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.BtnTratarMascota.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.BtnTratarMascota.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnTratarMascota.Font = new System.Drawing.Font("Microsoft YaHei Light", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnTratarMascota.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnTratarMascota.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnTratarMascota.Location = new System.Drawing.Point(28, 266);
            this.BtnTratarMascota.Name = "BtnTratarMascota";
            this.BtnTratarMascota.Size = new System.Drawing.Size(163, 34);
            this.BtnTratarMascota.TabIndex = 3;
            this.BtnTratarMascota.Text = "Tratar Mascota";
            this.BtnTratarMascota.UseVisualStyleBackColor = false;
            this.BtnTratarMascota.Click += new System.EventHandler(this.BtnCompras_Click);
            // 
            // BtnMascota
            // 
            this.BtnMascota.BackColor = System.Drawing.Color.Aqua;
            this.BtnMascota.FlatAppearance.BorderColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.BtnMascota.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.BtnMascota.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnMascota.Font = new System.Drawing.Font("Microsoft YaHei Light", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnMascota.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnMascota.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnMascota.Location = new System.Drawing.Point(28, 226);
            this.BtnMascota.Name = "BtnMascota";
            this.BtnMascota.Size = new System.Drawing.Size(163, 34);
            this.BtnMascota.TabIndex = 2;
            this.BtnMascota.Text = "Mascota";
            this.BtnMascota.UseVisualStyleBackColor = false;
            this.BtnMascota.Click += new System.EventHandler(this.BtnVentas_Click);
            // 
            // BtnCliente
            // 
            this.BtnCliente.BackColor = System.Drawing.Color.Aqua;
            this.BtnCliente.FlatAppearance.BorderColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.BtnCliente.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.BtnCliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnCliente.Font = new System.Drawing.Font("Microsoft YaHei Light", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnCliente.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnCliente.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnCliente.Location = new System.Drawing.Point(28, 186);
            this.BtnCliente.Name = "BtnCliente";
            this.BtnCliente.Size = new System.Drawing.Size(163, 34);
            this.BtnCliente.TabIndex = 1;
            this.BtnCliente.Text = "Cliente";
            this.BtnCliente.UseVisualStyleBackColor = false;
            this.BtnCliente.Click += new System.EventHandler(this.BtnProductos_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(28, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(163, 148);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // PContenedor
            // 
            this.PContenedor.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.PContenedor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PContenedor.Location = new System.Drawing.Point(217, 42);
            this.PContenedor.Name = "PContenedor";
            this.PContenedor.Size = new System.Drawing.Size(601, 640);
            this.PContenedor.TabIndex = 5;
            this.PContenedor.Paint += new System.Windows.Forms.PaintEventHandler(this.PContenedor_Paint);
            // 
            // BtnCierre
            // 
            this.BtnCierre.BackColor = System.Drawing.Color.DimGray;
            this.BtnCierre.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnCierre.Dock = System.Windows.Forms.DockStyle.Right;
            this.BtnCierre.Image = ((System.Drawing.Image)(resources.GetObject("BtnCierre.Image")));
            this.BtnCierre.Location = new System.Drawing.Point(778, 0);
            this.BtnCierre.Name = "BtnCierre";
            this.BtnCierre.Size = new System.Drawing.Size(40, 42);
            this.BtnCierre.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.BtnCierre.TabIndex = 0;
            this.BtnCierre.TabStop = false;
            this.BtnCierre.Click += new System.EventHandler(this.BtnCierre_Click);
            // 
            // BtnMaxi
            // 
            this.BtnMaxi.BackColor = System.Drawing.Color.DimGray;
            this.BtnMaxi.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnMaxi.Dock = System.Windows.Forms.DockStyle.Right;
            this.BtnMaxi.Image = ((System.Drawing.Image)(resources.GetObject("BtnMaxi.Image")));
            this.BtnMaxi.Location = new System.Drawing.Point(738, 0);
            this.BtnMaxi.Name = "BtnMaxi";
            this.BtnMaxi.Size = new System.Drawing.Size(40, 42);
            this.BtnMaxi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.BtnMaxi.TabIndex = 1;
            this.BtnMaxi.TabStop = false;
            this.BtnMaxi.Click += new System.EventHandler(this.BtnMaxi_Click);
            // 
            // BtnResta
            // 
            this.BtnResta.BackColor = System.Drawing.Color.DimGray;
            this.BtnResta.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnResta.Dock = System.Windows.Forms.DockStyle.Right;
            this.BtnResta.Image = ((System.Drawing.Image)(resources.GetObject("BtnResta.Image")));
            this.BtnResta.Location = new System.Drawing.Point(698, 0);
            this.BtnResta.Name = "BtnResta";
            this.BtnResta.Size = new System.Drawing.Size(40, 42);
            this.BtnResta.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.BtnResta.TabIndex = 2;
            this.BtnResta.TabStop = false;
            this.BtnResta.Visible = false;
            this.BtnResta.Click += new System.EventHandler(this.BtnResta_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("New York", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(3, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(188, 25);
            this.label1.TabIndex = 2;
            this.label1.Text = "Los Consentidos";
            // 
            // BtnMini
            // 
            this.BtnMini.BackColor = System.Drawing.Color.DimGray;
            this.BtnMini.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnMini.Dock = System.Windows.Forms.DockStyle.Right;
            this.BtnMini.Image = ((System.Drawing.Image)(resources.GetObject("BtnMini.Image")));
            this.BtnMini.Location = new System.Drawing.Point(658, 0);
            this.BtnMini.Name = "BtnMini";
            this.BtnMini.Size = new System.Drawing.Size(40, 42);
            this.BtnMini.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.BtnMini.TabIndex = 3;
            this.BtnMini.TabStop = false;
            this.BtnMini.Click += new System.EventHandler(this.BtnMini_Click);
            // 
            // BTitulo
            // 
            this.BTitulo.BackColor = System.Drawing.Color.DimGray;
            this.BTitulo.Controls.Add(this.BtnMini);
            this.BTitulo.Controls.Add(this.label1);
            this.BTitulo.Controls.Add(this.BtnResta);
            this.BTitulo.Controls.Add(this.BtnMaxi);
            this.BTitulo.Controls.Add(this.BtnCierre);
            this.BTitulo.Dock = System.Windows.Forms.DockStyle.Top;
            this.BTitulo.Location = new System.Drawing.Point(0, 0);
            this.BTitulo.Name = "BTitulo";
            this.BTitulo.Size = new System.Drawing.Size(818, 42);
            this.BTitulo.TabIndex = 3;
            // 
            // BtnOpciones
            // 
            this.BtnOpciones.BackColor = System.Drawing.Color.Aqua;
            this.BtnOpciones.FlatAppearance.BorderColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.BtnOpciones.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.BtnOpciones.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnOpciones.Font = new System.Drawing.Font("Microsoft YaHei Light", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnOpciones.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnOpciones.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnOpciones.Location = new System.Drawing.Point(28, 386);
            this.BtnOpciones.Name = "BtnOpciones";
            this.BtnOpciones.Size = new System.Drawing.Size(163, 34);
            this.BtnOpciones.TabIndex = 6;
            this.BtnOpciones.Text = "Opciones";
            this.BtnOpciones.UseVisualStyleBackColor = false;
            this.BtnOpciones.Click += new System.EventHandler(this.BtnOpciones_Click);
            // 
            // Subcrud
            // 
            this.Subcrud.Controls.Add(this.BtnEmedicamentos);
            this.Subcrud.Controls.Add(this.BtnEdenfermedad);
            this.Subcrud.Controls.Add(this.BtnEdmascota);
            this.Subcrud.Controls.Add(this.BtnEdicliente);
            this.Subcrud.Location = new System.Drawing.Point(8, 426);
            this.Subcrud.Name = "Subcrud";
            this.Subcrud.Size = new System.Drawing.Size(249, 166);
            this.Subcrud.TabIndex = 5;
            this.Subcrud.Visible = false;
            // 
            // BtnEdmascota
            // 
            this.BtnEdmascota.BackColor = System.Drawing.Color.Aqua;
            this.BtnEdmascota.FlatAppearance.BorderColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.BtnEdmascota.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.BtnEdmascota.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnEdmascota.Font = new System.Drawing.Font("Microsoft YaHei Light", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnEdmascota.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnEdmascota.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnEdmascota.Location = new System.Drawing.Point(3, 43);
            this.BtnEdmascota.Name = "BtnEdmascota";
            this.BtnEdmascota.Size = new System.Drawing.Size(195, 34);
            this.BtnEdmascota.TabIndex = 5;
            this.BtnEdmascota.Text = "Editar Mascota";
            this.BtnEdmascota.UseVisualStyleBackColor = false;
            this.BtnEdmascota.Click += new System.EventHandler(this.BtnEdmascota_Click);
            // 
            // BtnEdicliente
            // 
            this.BtnEdicliente.BackColor = System.Drawing.Color.Aqua;
            this.BtnEdicliente.FlatAppearance.BorderColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.BtnEdicliente.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.BtnEdicliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnEdicliente.Font = new System.Drawing.Font("Microsoft YaHei Light", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnEdicliente.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnEdicliente.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnEdicliente.Location = new System.Drawing.Point(3, 3);
            this.BtnEdicliente.Name = "BtnEdicliente";
            this.BtnEdicliente.Size = new System.Drawing.Size(195, 34);
            this.BtnEdicliente.TabIndex = 4;
            this.BtnEdicliente.Text = "Editar Cliente";
            this.BtnEdicliente.UseVisualStyleBackColor = false;
            this.BtnEdicliente.Click += new System.EventHandler(this.BtnEdicliente_Click);
            // 
            // BtnEdenfermedad
            // 
            this.BtnEdenfermedad.BackColor = System.Drawing.Color.Aqua;
            this.BtnEdenfermedad.FlatAppearance.BorderColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.BtnEdenfermedad.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.BtnEdenfermedad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnEdenfermedad.Font = new System.Drawing.Font("Microsoft YaHei Light", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnEdenfermedad.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnEdenfermedad.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnEdenfermedad.Location = new System.Drawing.Point(3, 83);
            this.BtnEdenfermedad.Name = "BtnEdenfermedad";
            this.BtnEdenfermedad.Size = new System.Drawing.Size(195, 34);
            this.BtnEdenfermedad.TabIndex = 6;
            this.BtnEdenfermedad.Text = "Editar Enfermedad ";
            this.BtnEdenfermedad.UseVisualStyleBackColor = false;
            this.BtnEdenfermedad.Click += new System.EventHandler(this.BtnEdenfermedad_Click);
            // 
            // BtnEmedicamentos
            // 
            this.BtnEmedicamentos.BackColor = System.Drawing.Color.Aqua;
            this.BtnEmedicamentos.FlatAppearance.BorderColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.BtnEmedicamentos.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.BtnEmedicamentos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnEmedicamentos.Font = new System.Drawing.Font("Microsoft YaHei Light", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnEmedicamentos.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnEmedicamentos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnEmedicamentos.Location = new System.Drawing.Point(3, 123);
            this.BtnEmedicamentos.Name = "BtnEmedicamentos";
            this.BtnEmedicamentos.Size = new System.Drawing.Size(195, 34);
            this.BtnEmedicamentos.TabIndex = 7;
            this.BtnEmedicamentos.Text = "Editar Medicamentos";
            this.BtnEmedicamentos.UseVisualStyleBackColor = false;
            this.BtnEmedicamentos.Click += new System.EventHandler(this.BtnEmedicamentos_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(818, 682);
            this.Controls.Add(this.PContenedor);
            this.Controls.Add(this.PVertical);
            this.Controls.Add(this.BTitulo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.PVertical.ResumeLayout(false);
            this.PSubmenu.ResumeLayout(false);
            this.SubReportes.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnCierre)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnMaxi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnResta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnMini)).EndInit();
            this.BTitulo.ResumeLayout(false);
            this.BTitulo.PerformLayout();
            this.Subcrud.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel PVertical;
        private System.Windows.Forms.Panel PSubmenu;
        private System.Windows.Forms.Button BtnMedicamento;
        private System.Windows.Forms.Button BtnEnfermedad;
        private System.Windows.Forms.Button BtnTratarMascota;
        private System.Windows.Forms.Button BtnMascota;
        private System.Windows.Forms.Button BtnCliente;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel PContenedor;
        private System.Windows.Forms.PictureBox BtnCierre;
        private System.Windows.Forms.PictureBox BtnMaxi;
        private System.Windows.Forms.PictureBox BtnResta;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox BtnMini;
        private System.Windows.Forms.Panel BTitulo;
        private System.Windows.Forms.Button BtnReportes;
        private System.Windows.Forms.Panel SubReportes;
        private System.Windows.Forms.Button BtnEnMedicamentos;
        private System.Windows.Forms.Button BtnEnTratadas;
        private System.Windows.Forms.Button BtnComparar;
        private System.Windows.Forms.Button BtnOpciones;
        private System.Windows.Forms.Panel Subcrud;
        private System.Windows.Forms.Button BtnEdmascota;
        private System.Windows.Forms.Button BtnEdicliente;
        private System.Windows.Forms.Button BtnEmedicamentos;
        private System.Windows.Forms.Button BtnEdenfermedad;
    }
}

