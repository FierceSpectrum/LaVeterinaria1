﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LaVeterinaria1
{
    public partial class Form1 : Form

    {
        String Ruta = "";
        bool nuevo = true;

        private void Abrirfh(object FormHijo)
        {
            if (this.PContenedor.Controls.Count > 0)
            {
                this.PContenedor.Controls.RemoveAt(0);
            }
            Form fh = FormHijo as Form;


            fh.TopLevel = false;


            fh.Dock = DockStyle.Fill;

            this.PContenedor.Controls.Add(fh);
            this.PContenedor.Tag = fh;
            fh.Show();
        }
        bool movimiento = false;
            public Form1()
        {
            InitializeComponent();
        }

        private void BtnCierre_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void BtnMaxi_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            BtnMaxi.Visible = false;
            BtnResta.Visible = true;
        }

        private void BtnResta_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
            BtnMaxi.Visible = true;
            BtnResta.Visible = false;
        }

        private void BtnMini_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void PContenedor_Paint(object sender, PaintEventArgs e)
        {

        }

        private void BtnProductos_Click(object sender, EventArgs e)
        {
            Abrirfh(new Cliente());
        }

        private void BtnVentas_Click(object sender, EventArgs e)
        {
            Abrirfh(new Mascota());
        }

        private void BtnCompras_Click(object sender, EventArgs e)
        {
            PSubmenu.Visible = true;
            if (this.PContenedor.Controls.Count > 0)
            {
                this.PContenedor.Controls.RemoveAt(0);
            }
            SubReportes.Visible = false;


        }

        private void BtnEnfermedad_Click(object sender, EventArgs e)
        {
            PSubmenu.Visible = false;

            Abrirfh(new InEnfermedad());
        }

        private void BtnMedicamento_Click(object sender, EventArgs e)
        {
            PSubmenu.Visible = false;
            Abrirfh(new InMedicamento());
        }

        private void BtnReportes_Click(object sender, EventArgs e)
        {
           SubReportes.Visible = true;
            if (this.PContenedor.Controls.Count > 0)
            {
                this.PContenedor.Controls.RemoveAt(0);
            }


        }

        private void button2_Click(object sender, EventArgs e)
        {
            SubReportes.Visible = false;
            Abrirfh(new InReportesEn());



        }

        private void button1_Click(object sender, EventArgs e)
        {
            SubReportes.Visible = false;


            Abrirfh(new InReporteMedi());
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            
        }

        private void BtnComparar_Click(object sender, EventArgs e)
        {
            Abrirfh(new InComparar());
        }

        private void BtnOpciones_Click(object sender, EventArgs e)
        {
            Subcrud.Visible = true;
            if (this.PContenedor.Controls.Count > 0)
            {
                this.PContenedor.Controls.RemoveAt(0);
            }
        }

        private void BtnEdicliente_Click(object sender, EventArgs e)
        {
            Subcrud.Visible = false;
            Abrirfh(new CrudCliente());

        }

        private void BtnEdmascota_Click(object sender, EventArgs e)
        {
            
            Subcrud.Visible = false;
            Abrirfh(new CrudMascota());
        }

        private void BtnEdenfermedad_Click(object sender, EventArgs e)
        {
            Subcrud.Visible = false;
        }

        private void BtnEmedicamentos_Click(object sender, EventArgs e)
        {
            Subcrud.Visible = false;
        }
    }
}
