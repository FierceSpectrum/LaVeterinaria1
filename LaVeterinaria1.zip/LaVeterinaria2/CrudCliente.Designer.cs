﻿namespace LaVeterinaria1
{
    partial class CrudCliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CrudCliente));
            this.BtnActualizar = new System.Windows.Forms.Button();
            this.Btnleercliente = new System.Windows.Forms.Button();
            this.BtnCcliente = new System.Windows.Forms.Button();
            this.BtnBoCliente = new System.Windows.Forms.Button();
            this.PVercliente = new System.Windows.Forms.Panel();
            this.Pactualizar = new System.Windows.Forms.Panel();
            this.PborrarCliente = new System.Windows.Forms.Panel();
            this.PCcliente = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.TxtIndentificacion = new System.Windows.Forms.TextBox();
            this.TxtNombre = new System.Windows.Forms.TextBox();
            this.TxtApellido = new System.Windows.Forms.TextBox();
            this.TxtTelefono = new System.Windows.Forms.TextBox();
            this.TxtDireccion = new System.Windows.Forms.TextBox();
            this.BtnAceptar = new System.Windows.Forms.Button();
            this.BtnCancelar = new System.Windows.Forms.Button();
            this.BtnSalir = new System.Windows.Forms.Button();
            this.Cmb_Leercliente = new System.Windows.Forms.ComboBox();
            this.Cmb_Acliente = new System.Windows.Forms.ComboBox();
            this.Cmb_BorrarCliente = new System.Windows.Forms.ComboBox();
            this.PVercliente.SuspendLayout();
            this.Pactualizar.SuspendLayout();
            this.PborrarCliente.SuspendLayout();
            this.PCcliente.SuspendLayout();
            this.SuspendLayout();
            // 
            // BtnActualizar
            // 
            this.BtnActualizar.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BtnActualizar.FlatAppearance.BorderColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.BtnActualizar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.BtnActualizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnActualizar.Font = new System.Drawing.Font("Microsoft YaHei Light", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnActualizar.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnActualizar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnActualizar.Location = new System.Drawing.Point(12, 152);
            this.BtnActualizar.Name = "BtnActualizar";
            this.BtnActualizar.Size = new System.Drawing.Size(163, 34);
            this.BtnActualizar.TabIndex = 4;
            this.BtnActualizar.Text = "Actualizar Cliente";
            this.BtnActualizar.UseVisualStyleBackColor = false;
            this.BtnActualizar.Click += new System.EventHandler(this.BtnActualizar_Click);
            // 
            // Btnleercliente
            // 
            this.Btnleercliente.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Btnleercliente.FlatAppearance.BorderColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.Btnleercliente.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.Btnleercliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btnleercliente.Font = new System.Drawing.Font("Microsoft YaHei Light", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btnleercliente.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Btnleercliente.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Btnleercliente.Location = new System.Drawing.Point(12, 102);
            this.Btnleercliente.Name = "Btnleercliente";
            this.Btnleercliente.Size = new System.Drawing.Size(163, 34);
            this.Btnleercliente.TabIndex = 5;
            this.Btnleercliente.Text = "Leer Cliente";
            this.Btnleercliente.UseVisualStyleBackColor = false;
            this.Btnleercliente.Click += new System.EventHandler(this.Btnleercliente_Click);
            // 
            // BtnCcliente
            // 
            this.BtnCcliente.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BtnCcliente.FlatAppearance.BorderColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.BtnCcliente.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.BtnCcliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnCcliente.Font = new System.Drawing.Font("Microsoft YaHei Light", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnCcliente.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnCcliente.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnCcliente.Location = new System.Drawing.Point(12, 50);
            this.BtnCcliente.Name = "BtnCcliente";
            this.BtnCcliente.Size = new System.Drawing.Size(163, 34);
            this.BtnCcliente.TabIndex = 6;
            this.BtnCcliente.Text = "Crear Cliente";
            this.BtnCcliente.UseVisualStyleBackColor = false;
            this.BtnCcliente.Click += new System.EventHandler(this.BtnCcliente_Click);
            // 
            // BtnBoCliente
            // 
            this.BtnBoCliente.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BtnBoCliente.FlatAppearance.BorderColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.BtnBoCliente.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.BtnBoCliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnBoCliente.Font = new System.Drawing.Font("Microsoft YaHei Light", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnBoCliente.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnBoCliente.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnBoCliente.Location = new System.Drawing.Point(12, 206);
            this.BtnBoCliente.Name = "BtnBoCliente";
            this.BtnBoCliente.Size = new System.Drawing.Size(163, 34);
            this.BtnBoCliente.TabIndex = 7;
            this.BtnBoCliente.Text = "Borrar Cliente";
            this.BtnBoCliente.UseVisualStyleBackColor = false;
            this.BtnBoCliente.Click += new System.EventHandler(this.BtnBoCliente_Click);
            // 
            // PVercliente
            // 
            this.PVercliente.Controls.Add(this.Cmb_Leercliente);
            this.PVercliente.Location = new System.Drawing.Point(257, 99);
            this.PVercliente.Name = "PVercliente";
            this.PVercliente.Size = new System.Drawing.Size(202, 37);
            this.PVercliente.TabIndex = 11;
            this.PVercliente.Visible = false;
            this.PVercliente.Paint += new System.Windows.Forms.PaintEventHandler(this.PVercliente_Paint);
            // 
            // Pactualizar
            // 
            this.Pactualizar.Controls.Add(this.Cmb_Acliente);
            this.Pactualizar.Location = new System.Drawing.Point(257, 152);
            this.Pactualizar.Name = "Pactualizar";
            this.Pactualizar.Size = new System.Drawing.Size(202, 37);
            this.Pactualizar.TabIndex = 12;
            this.Pactualizar.Visible = false;
            // 
            // PborrarCliente
            // 
            this.PborrarCliente.Controls.Add(this.Cmb_BorrarCliente);
            this.PborrarCliente.Location = new System.Drawing.Point(257, 206);
            this.PborrarCliente.Name = "PborrarCliente";
            this.PborrarCliente.Size = new System.Drawing.Size(202, 37);
            this.PborrarCliente.TabIndex = 12;
            this.PborrarCliente.Visible = false;
            // 
            // PCcliente
            // 
            this.PCcliente.Controls.Add(this.TxtDireccion);
            this.PCcliente.Controls.Add(this.TxtTelefono);
            this.PCcliente.Controls.Add(this.TxtApellido);
            this.PCcliente.Controls.Add(this.TxtNombre);
            this.PCcliente.Controls.Add(this.TxtIndentificacion);
            this.PCcliente.Controls.Add(this.label6);
            this.PCcliente.Controls.Add(this.label5);
            this.PCcliente.Controls.Add(this.label4);
            this.PCcliente.Controls.Add(this.label3);
            this.PCcliente.Controls.Add(this.label2);
            this.PCcliente.Controls.Add(this.label1);
            this.PCcliente.Location = new System.Drawing.Point(235, 50);
            this.PCcliente.Name = "PCcliente";
            this.PCcliente.Size = new System.Drawing.Size(313, 220);
            this.PCcliente.TabIndex = 13;
            this.PCcliente.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("New York", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(11, 81);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Identificacion:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("New York", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(11, 107);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nombre:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("New York", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(11, 138);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Apellido:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("New York", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(13, 168);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "Teléfono:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("New York", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(11, 193);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 15);
            this.label5.TabIndex = 4;
            this.label5.Text = "Direccion:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("New York", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(62, 26);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(119, 15);
            this.label6.TabIndex = 5;
            this.label6.Text = "Ingrese los Datos";
            // 
            // TxtIndentificacion
            // 
            this.TxtIndentificacion.Location = new System.Drawing.Point(126, 76);
            this.TxtIndentificacion.Name = "TxtIndentificacion";
            this.TxtIndentificacion.Size = new System.Drawing.Size(141, 20);
            this.TxtIndentificacion.TabIndex = 6;
            // 
            // TxtNombre
            // 
            this.TxtNombre.Location = new System.Drawing.Point(126, 102);
            this.TxtNombre.Name = "TxtNombre";
            this.TxtNombre.Size = new System.Drawing.Size(141, 20);
            this.TxtNombre.TabIndex = 7;
            // 
            // TxtApellido
            // 
            this.TxtApellido.Location = new System.Drawing.Point(126, 133);
            this.TxtApellido.Name = "TxtApellido";
            this.TxtApellido.Size = new System.Drawing.Size(141, 20);
            this.TxtApellido.TabIndex = 8;
            // 
            // TxtTelefono
            // 
            this.TxtTelefono.Location = new System.Drawing.Point(126, 162);
            this.TxtTelefono.Name = "TxtTelefono";
            this.TxtTelefono.Size = new System.Drawing.Size(141, 20);
            this.TxtTelefono.TabIndex = 9;
            // 
            // TxtDireccion
            // 
            this.TxtDireccion.Location = new System.Drawing.Point(126, 188);
            this.TxtDireccion.Name = "TxtDireccion";
            this.TxtDireccion.Size = new System.Drawing.Size(141, 20);
            this.TxtDireccion.TabIndex = 10;
            // 
            // BtnAceptar
            // 
            this.BtnAceptar.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BtnAceptar.FlatAppearance.BorderColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.BtnAceptar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.BtnAceptar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnAceptar.Font = new System.Drawing.Font("Microsoft YaHei Light", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnAceptar.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnAceptar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnAceptar.Location = new System.Drawing.Point(34, 444);
            this.BtnAceptar.Name = "BtnAceptar";
            this.BtnAceptar.Size = new System.Drawing.Size(163, 34);
            this.BtnAceptar.TabIndex = 14;
            this.BtnAceptar.Text = "Aceptar";
            this.BtnAceptar.UseVisualStyleBackColor = false;
            // 
            // BtnCancelar
            // 
            this.BtnCancelar.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BtnCancelar.FlatAppearance.BorderColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.BtnCancelar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.BtnCancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnCancelar.Font = new System.Drawing.Font("Microsoft YaHei Light", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnCancelar.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnCancelar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnCancelar.Location = new System.Drawing.Point(235, 444);
            this.BtnCancelar.Name = "BtnCancelar";
            this.BtnCancelar.Size = new System.Drawing.Size(163, 34);
            this.BtnCancelar.TabIndex = 15;
            this.BtnCancelar.Text = "Cancelar";
            this.BtnCancelar.UseVisualStyleBackColor = false;
            // 
            // BtnSalir
            // 
            this.BtnSalir.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BtnSalir.FlatAppearance.BorderColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.BtnSalir.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.BtnSalir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnSalir.Font = new System.Drawing.Font("Microsoft YaHei Light", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSalir.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnSalir.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnSalir.Location = new System.Drawing.Point(428, 444);
            this.BtnSalir.Name = "BtnSalir";
            this.BtnSalir.Size = new System.Drawing.Size(163, 34);
            this.BtnSalir.TabIndex = 16;
            this.BtnSalir.Text = "Salir";
            this.BtnSalir.UseVisualStyleBackColor = false;
            // 
            // Cmb_Leercliente
            // 
            this.Cmb_Leercliente.FormattingEnabled = true;
            this.Cmb_Leercliente.Items.AddRange(new object[] {
            "Hola\t",
            "que",
            "hace",
            "todo",
            "bien?"});
            this.Cmb_Leercliente.Location = new System.Drawing.Point(4, 4);
            this.Cmb_Leercliente.Margin = new System.Windows.Forms.Padding(4);
            this.Cmb_Leercliente.Name = "Cmb_Leercliente";
            this.Cmb_Leercliente.Size = new System.Drawing.Size(180, 21);
            this.Cmb_Leercliente.TabIndex = 6;
            // 
            // Cmb_Acliente
            // 
            this.Cmb_Acliente.FormattingEnabled = true;
            this.Cmb_Acliente.Items.AddRange(new object[] {
            "Amarillo",
            "Azul",
            "Rojo",
            "Verde",
            "Negro"});
            this.Cmb_Acliente.Location = new System.Drawing.Point(4, 4);
            this.Cmb_Acliente.Margin = new System.Windows.Forms.Padding(4);
            this.Cmb_Acliente.Name = "Cmb_Acliente";
            this.Cmb_Acliente.Size = new System.Drawing.Size(180, 21);
            this.Cmb_Acliente.TabIndex = 6;
            // 
            // Cmb_BorrarCliente
            // 
            this.Cmb_BorrarCliente.FormattingEnabled = true;
            this.Cmb_BorrarCliente.Items.AddRange(new object[] {
            "Amarillo",
            "Azul",
            "Rojo",
            "Verde",
            "Negro"});
            this.Cmb_BorrarCliente.Location = new System.Drawing.Point(4, 6);
            this.Cmb_BorrarCliente.Margin = new System.Windows.Forms.Padding(4);
            this.Cmb_BorrarCliente.Name = "Cmb_BorrarCliente";
            this.Cmb_BorrarCliente.Size = new System.Drawing.Size(180, 21);
            this.Cmb_BorrarCliente.TabIndex = 6;
            // 
            // CrudCliente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(641, 525);
            this.Controls.Add(this.BtnSalir);
            this.Controls.Add(this.BtnCancelar);
            this.Controls.Add(this.BtnAceptar);
            this.Controls.Add(this.PCcliente);
            this.Controls.Add(this.PborrarCliente);
            this.Controls.Add(this.Pactualizar);
            this.Controls.Add(this.PVercliente);
            this.Controls.Add(this.BtnBoCliente);
            this.Controls.Add(this.BtnCcliente);
            this.Controls.Add(this.Btnleercliente);
            this.Controls.Add(this.BtnActualizar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "CrudCliente";
            this.Text = "CrudCliente";
            this.PVercliente.ResumeLayout(false);
            this.Pactualizar.ResumeLayout(false);
            this.PborrarCliente.ResumeLayout(false);
            this.PCcliente.ResumeLayout(false);
            this.PCcliente.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnActualizar;
        private System.Windows.Forms.Button Btnleercliente;
        private System.Windows.Forms.Button BtnCcliente;
        private System.Windows.Forms.Button BtnBoCliente;
        private System.Windows.Forms.Panel PVercliente;
        private System.Windows.Forms.Panel Pactualizar;
        private System.Windows.Forms.Panel PborrarCliente;
        private System.Windows.Forms.Panel PCcliente;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox TxtDireccion;
        private System.Windows.Forms.TextBox TxtTelefono;
        private System.Windows.Forms.TextBox TxtApellido;
        private System.Windows.Forms.TextBox TxtNombre;
        private System.Windows.Forms.TextBox TxtIndentificacion;
        private System.Windows.Forms.Button BtnAceptar;
        private System.Windows.Forms.Button BtnCancelar;
        private System.Windows.Forms.Button BtnSalir;
        private System.Windows.Forms.ComboBox Cmb_Leercliente;
        private System.Windows.Forms.ComboBox Cmb_Acliente;
        private System.Windows.Forms.ComboBox Cmb_BorrarCliente;
    }
}