﻿namespace LaVeterinaria1
{
    partial class CrudMascota
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CrudMascota));
            this.BtnSalir = new System.Windows.Forms.Button();
            this.BtnCancelar = new System.Windows.Forms.Button();
            this.BtnAceptar = new System.Windows.Forms.Button();
            this.BtnBoCliente = new System.Windows.Forms.Button();
            this.BtnCcliente = new System.Windows.Forms.Button();
            this.Btnleercliente = new System.Windows.Forms.Button();
            this.BtnActualizar = new System.Windows.Forms.Button();
            this.PborrarMascota = new System.Windows.Forms.Panel();
            this.Cmb_Borrarmascota = new System.Windows.Forms.ComboBox();
            this.PactualizarMas = new System.Windows.Forms.Panel();
            this.Cmb_AMascota = new System.Windows.Forms.ComboBox();
            this.PvMascota = new System.Windows.Forms.Panel();
            this.Cmb_LeerMascota = new System.Windows.Forms.ComboBox();
            this.PMascota = new System.Windows.Forms.Panel();
            this.TxtDireccion = new System.Windows.Forms.TextBox();
            this.TxtTelefono = new System.Windows.Forms.TextBox();
            this.TxtApellido = new System.Windows.Forms.TextBox();
            this.TxtNombre = new System.Windows.Forms.TextBox();
            this.TxtIndentificacion = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.PborrarMascota.SuspendLayout();
            this.PactualizarMas.SuspendLayout();
            this.PvMascota.SuspendLayout();
            this.PMascota.SuspendLayout();
            this.SuspendLayout();
            // 
            // BtnSalir
            // 
            this.BtnSalir.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BtnSalir.FlatAppearance.BorderColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.BtnSalir.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.BtnSalir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnSalir.Font = new System.Drawing.Font("Microsoft YaHei Light", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSalir.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnSalir.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnSalir.Location = new System.Drawing.Point(411, 421);
            this.BtnSalir.Name = "BtnSalir";
            this.BtnSalir.Size = new System.Drawing.Size(163, 34);
            this.BtnSalir.TabIndex = 24;
            this.BtnSalir.Text = "Salir";
            this.BtnSalir.UseVisualStyleBackColor = false;
            // 
            // BtnCancelar
            // 
            this.BtnCancelar.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BtnCancelar.FlatAppearance.BorderColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.BtnCancelar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.BtnCancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnCancelar.Font = new System.Drawing.Font("Microsoft YaHei Light", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnCancelar.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnCancelar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnCancelar.Location = new System.Drawing.Point(218, 421);
            this.BtnCancelar.Name = "BtnCancelar";
            this.BtnCancelar.Size = new System.Drawing.Size(163, 34);
            this.BtnCancelar.TabIndex = 23;
            this.BtnCancelar.Text = "Cancelar";
            this.BtnCancelar.UseVisualStyleBackColor = false;
            // 
            // BtnAceptar
            // 
            this.BtnAceptar.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BtnAceptar.FlatAppearance.BorderColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.BtnAceptar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.BtnAceptar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnAceptar.Font = new System.Drawing.Font("Microsoft YaHei Light", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnAceptar.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnAceptar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnAceptar.Location = new System.Drawing.Point(17, 421);
            this.BtnAceptar.Name = "BtnAceptar";
            this.BtnAceptar.Size = new System.Drawing.Size(163, 34);
            this.BtnAceptar.TabIndex = 22;
            this.BtnAceptar.Text = "Aceptar";
            this.BtnAceptar.UseVisualStyleBackColor = false;
            // 
            // BtnBoCliente
            // 
            this.BtnBoCliente.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BtnBoCliente.FlatAppearance.BorderColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.BtnBoCliente.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.BtnBoCliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnBoCliente.Font = new System.Drawing.Font("Microsoft YaHei Light", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnBoCliente.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnBoCliente.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnBoCliente.Location = new System.Drawing.Point(12, 183);
            this.BtnBoCliente.Name = "BtnBoCliente";
            this.BtnBoCliente.Size = new System.Drawing.Size(163, 34);
            this.BtnBoCliente.TabIndex = 20;
            this.BtnBoCliente.Text = "Borrar Mascota";
            this.BtnBoCliente.UseVisualStyleBackColor = false;
            this.BtnBoCliente.Click += new System.EventHandler(this.BtnBoCliente_Click);
            // 
            // BtnCcliente
            // 
            this.BtnCcliente.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BtnCcliente.FlatAppearance.BorderColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.BtnCcliente.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.BtnCcliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnCcliente.Font = new System.Drawing.Font("Microsoft YaHei Light", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnCcliente.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnCcliente.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnCcliente.Location = new System.Drawing.Point(12, 27);
            this.BtnCcliente.Name = "BtnCcliente";
            this.BtnCcliente.Size = new System.Drawing.Size(163, 34);
            this.BtnCcliente.TabIndex = 19;
            this.BtnCcliente.Text = "Crear Mascota";
            this.BtnCcliente.UseVisualStyleBackColor = false;
            this.BtnCcliente.Click += new System.EventHandler(this.BtnCcliente_Click);
            // 
            // Btnleercliente
            // 
            this.Btnleercliente.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Btnleercliente.FlatAppearance.BorderColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.Btnleercliente.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.Btnleercliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btnleercliente.Font = new System.Drawing.Font("Microsoft YaHei Light", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btnleercliente.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Btnleercliente.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Btnleercliente.Location = new System.Drawing.Point(12, 79);
            this.Btnleercliente.Name = "Btnleercliente";
            this.Btnleercliente.Size = new System.Drawing.Size(163, 34);
            this.Btnleercliente.TabIndex = 18;
            this.Btnleercliente.Text = "Leer Mascota";
            this.Btnleercliente.UseVisualStyleBackColor = false;
            this.Btnleercliente.Click += new System.EventHandler(this.Btnleercliente_Click);
            // 
            // BtnActualizar
            // 
            this.BtnActualizar.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BtnActualizar.FlatAppearance.BorderColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.BtnActualizar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.BtnActualizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnActualizar.Font = new System.Drawing.Font("Microsoft YaHei Light", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnActualizar.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnActualizar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnActualizar.Location = new System.Drawing.Point(12, 129);
            this.BtnActualizar.Name = "BtnActualizar";
            this.BtnActualizar.Size = new System.Drawing.Size(163, 34);
            this.BtnActualizar.TabIndex = 17;
            this.BtnActualizar.Text = "Actualizar Mascota";
            this.BtnActualizar.UseVisualStyleBackColor = false;
            this.BtnActualizar.Click += new System.EventHandler(this.BtnActualizar_Click);
            // 
            // PborrarMascota
            // 
            this.PborrarMascota.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.PborrarMascota.Controls.Add(this.Cmb_Borrarmascota);
            this.PborrarMascota.Location = new System.Drawing.Point(242, 186);
            this.PborrarMascota.Name = "PborrarMascota";
            this.PborrarMascota.Size = new System.Drawing.Size(202, 37);
            this.PborrarMascota.TabIndex = 27;
            this.PborrarMascota.Visible = false;
            // 
            // Cmb_Borrarmascota
            // 
            this.Cmb_Borrarmascota.FormattingEnabled = true;
            this.Cmb_Borrarmascota.Items.AddRange(new object[] {
            "Amarillo",
            "Azul",
            "Rojo",
            "Verde",
            "Negro"});
            this.Cmb_Borrarmascota.Location = new System.Drawing.Point(4, 6);
            this.Cmb_Borrarmascota.Margin = new System.Windows.Forms.Padding(4);
            this.Cmb_Borrarmascota.Name = "Cmb_Borrarmascota";
            this.Cmb_Borrarmascota.Size = new System.Drawing.Size(180, 21);
            this.Cmb_Borrarmascota.TabIndex = 6;
            // 
            // PactualizarMas
            // 
            this.PactualizarMas.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.PactualizarMas.Controls.Add(this.Cmb_AMascota);
            this.PactualizarMas.Location = new System.Drawing.Point(242, 132);
            this.PactualizarMas.Name = "PactualizarMas";
            this.PactualizarMas.Size = new System.Drawing.Size(202, 37);
            this.PactualizarMas.TabIndex = 26;
            this.PactualizarMas.Visible = false;
            // 
            // Cmb_AMascota
            // 
            this.Cmb_AMascota.FormattingEnabled = true;
            this.Cmb_AMascota.Items.AddRange(new object[] {
            "Amarillo",
            "Azul",
            "Rojo",
            "Verde",
            "Negro"});
            this.Cmb_AMascota.Location = new System.Drawing.Point(4, 4);
            this.Cmb_AMascota.Margin = new System.Windows.Forms.Padding(4);
            this.Cmb_AMascota.Name = "Cmb_AMascota";
            this.Cmb_AMascota.Size = new System.Drawing.Size(180, 21);
            this.Cmb_AMascota.TabIndex = 6;
            // 
            // PvMascota
            // 
            this.PvMascota.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.PvMascota.Controls.Add(this.Cmb_LeerMascota);
            this.PvMascota.Location = new System.Drawing.Point(242, 79);
            this.PvMascota.Name = "PvMascota";
            this.PvMascota.Size = new System.Drawing.Size(202, 37);
            this.PvMascota.TabIndex = 25;
            this.PvMascota.Visible = false;
            this.PvMascota.Paint += new System.Windows.Forms.PaintEventHandler(this.PvMascota_Paint);
            // 
            // Cmb_LeerMascota
            // 
            this.Cmb_LeerMascota.FormattingEnabled = true;
            this.Cmb_LeerMascota.Items.AddRange(new object[] {
            "Hola\t",
            "que",
            "hace",
            "todo",
            "bien?"});
            this.Cmb_LeerMascota.Location = new System.Drawing.Point(4, 4);
            this.Cmb_LeerMascota.Margin = new System.Windows.Forms.Padding(4);
            this.Cmb_LeerMascota.Name = "Cmb_LeerMascota";
            this.Cmb_LeerMascota.Size = new System.Drawing.Size(180, 21);
            this.Cmb_LeerMascota.TabIndex = 6;
            // 
            // PMascota
            // 
            this.PMascota.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.PMascota.Controls.Add(this.TxtDireccion);
            this.PMascota.Controls.Add(this.TxtTelefono);
            this.PMascota.Controls.Add(this.TxtApellido);
            this.PMascota.Controls.Add(this.TxtNombre);
            this.PMascota.Controls.Add(this.TxtIndentificacion);
            this.PMascota.Controls.Add(this.label6);
            this.PMascota.Controls.Add(this.label5);
            this.PMascota.Controls.Add(this.label4);
            this.PMascota.Controls.Add(this.label3);
            this.PMascota.Controls.Add(this.label2);
            this.PMascota.Controls.Add(this.label1);
            this.PMascota.Location = new System.Drawing.Point(218, 27);
            this.PMascota.Name = "PMascota";
            this.PMascota.Size = new System.Drawing.Size(313, 220);
            this.PMascota.TabIndex = 28;
            this.PMascota.Visible = false;
            // 
            // TxtDireccion
            // 
            this.TxtDireccion.Location = new System.Drawing.Point(126, 188);
            this.TxtDireccion.Name = "TxtDireccion";
            this.TxtDireccion.Size = new System.Drawing.Size(141, 20);
            this.TxtDireccion.TabIndex = 10;
            // 
            // TxtTelefono
            // 
            this.TxtTelefono.Location = new System.Drawing.Point(126, 162);
            this.TxtTelefono.Name = "TxtTelefono";
            this.TxtTelefono.Size = new System.Drawing.Size(141, 20);
            this.TxtTelefono.TabIndex = 9;
            // 
            // TxtApellido
            // 
            this.TxtApellido.Location = new System.Drawing.Point(126, 133);
            this.TxtApellido.Name = "TxtApellido";
            this.TxtApellido.Size = new System.Drawing.Size(141, 20);
            this.TxtApellido.TabIndex = 8;
            // 
            // TxtNombre
            // 
            this.TxtNombre.Location = new System.Drawing.Point(126, 102);
            this.TxtNombre.Name = "TxtNombre";
            this.TxtNombre.Size = new System.Drawing.Size(141, 20);
            this.TxtNombre.TabIndex = 7;
            // 
            // TxtIndentificacion
            // 
            this.TxtIndentificacion.Location = new System.Drawing.Point(126, 76);
            this.TxtIndentificacion.Name = "TxtIndentificacion";
            this.TxtIndentificacion.Size = new System.Drawing.Size(141, 20);
            this.TxtIndentificacion.TabIndex = 6;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("New York", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(62, 26);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(119, 15);
            this.label6.TabIndex = 5;
            this.label6.Text = "Ingrese los Datos";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("New York", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(11, 193);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 15);
            this.label5.TabIndex = 4;
            this.label5.Text = "Direccion:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("New York", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(13, 168);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "Teléfono:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("New York", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(11, 138);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Apellido:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("New York", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(11, 107);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nombre:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("New York", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(11, 81);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Identificacion:";
            // 
            // CrudMascota
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(568, 482);
            this.Controls.Add(this.PMascota);
            this.Controls.Add(this.PborrarMascota);
            this.Controls.Add(this.PactualizarMas);
            this.Controls.Add(this.PvMascota);
            this.Controls.Add(this.BtnSalir);
            this.Controls.Add(this.BtnCancelar);
            this.Controls.Add(this.BtnAceptar);
            this.Controls.Add(this.BtnBoCliente);
            this.Controls.Add(this.BtnCcliente);
            this.Controls.Add(this.Btnleercliente);
            this.Controls.Add(this.BtnActualizar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "CrudMascota";
            this.Text = "CrudMascota";
            this.Load += new System.EventHandler(this.CrudMascota_Load);
            this.PborrarMascota.ResumeLayout(false);
            this.PactualizarMas.ResumeLayout(false);
            this.PvMascota.ResumeLayout(false);
            this.PMascota.ResumeLayout(false);
            this.PMascota.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnSalir;
        private System.Windows.Forms.Button BtnCancelar;
        private System.Windows.Forms.Button BtnAceptar;
        private System.Windows.Forms.Button BtnBoCliente;
        private System.Windows.Forms.Button BtnCcliente;
        private System.Windows.Forms.Button Btnleercliente;
        private System.Windows.Forms.Button BtnActualizar;
        private System.Windows.Forms.Panel PborrarMascota;
        private System.Windows.Forms.ComboBox Cmb_Borrarmascota;
        private System.Windows.Forms.Panel PactualizarMas;
        private System.Windows.Forms.ComboBox Cmb_AMascota;
        private System.Windows.Forms.Panel PvMascota;
        private System.Windows.Forms.ComboBox Cmb_LeerMascota;
        private System.Windows.Forms.Panel PMascota;
        private System.Windows.Forms.TextBox TxtDireccion;
        private System.Windows.Forms.TextBox TxtTelefono;
        private System.Windows.Forms.TextBox TxtApellido;
        private System.Windows.Forms.TextBox TxtNombre;
        private System.Windows.Forms.TextBox TxtIndentificacion;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}