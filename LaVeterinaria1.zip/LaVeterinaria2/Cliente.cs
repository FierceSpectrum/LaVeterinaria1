﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LaVeterinaria1;
using System.IO;



namespace LaVeterinaria1
{
    public partial class Cliente : Form 
    {
        String Ruta = "";
        bool nuevo = true;

        public Cliente()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void BtnMascota_Click(object sender, EventArgs e)
        {
            // Form1.Abrirfh(new Mascota());

        }

        private void Cliente_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Cliente.Text = "";
            //nuevo = true;

        }

        private void BtnSalir_Click(object sender, EventArgs e)
        {

        }
    } }
